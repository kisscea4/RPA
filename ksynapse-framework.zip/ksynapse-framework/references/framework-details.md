# KSynapse Framework 하위 흐름 상세 액션 맵

해운A05 창에서 실측한 구조(ver 1.0.2). 과제별로 Process 상태의 비즈니스 훅 호출부만 다르고 나머지는 공통.

## Main (3액션)

1. 설명: [KSynapse] Framework ver 1.0.2 / CollectError에 데스크톱 흐름 실행 오류 메시지 parsing 추가
2. 설명: ProcessID - ProcessName / 개발자 / 요약 (기재 규약)
3. 하위 흐름 실행: [KSynapse] CallFramework

## [KSynapse] CallFramework (5액션)

1. 블록 오류 시 "Main: 오류 정보 수집"
2.   InitProcess (커스텀 액션)
3.   하위 흐름 실행: [KSynapse] Framework
4.   EndProcess (커스텀 액션)
5. End

## [KSynapse] InitVariables (14액션)

Out_Dic_Error={}, Bool_InitOnceEnd=False, Int_RetryNumber_Init/Process/Finish=0, Int_TransactionNumber=0,
Dbl_SuccessRate=Dic_Config['SuccessRate'], Dbl_SuccessAssignmentRate=Dic_Config['SuccessAssignmentRate'],
Bool_IsPRD=Dic_Config['IsPRD'], Str_InputFolderPath/OutputFolderPath/DataFolderPath=Dic_Config[각 키]

## [KSynapse] Framework (168액션) — 상태 머신 본체

### Start (1~3)
[KSynapse] InitVariables 실행.

### Init (4~57)
- 초기화(6~9): Str_CurrentState='Init', Dic_Error={}
- 실행(10~27): 블록 오류 시(RetryNumber_Init++, 블록 끝 이동) {
  - If Bool_InitOnceEnd<>True → [Business] InitOnce → Bool_InitOnceEnd=True
  - [Business] InitRetryable
  - If DT_TransactionData 비면: DownloadBeforeTransaction(커스텀) →
    Str_TransactionFilePath 있으면 CSV→DT_TransactionResult(재개 모드),
    없으면 [Business] SetTransactionData → MakeTransaction(커스텀) }
- 탈출(28~56): Dic_Error 비면 RetryNumber_Init=0, GetTransactionItem으로 이동.
  Else Switch Status: 'SE'→CloseApplications(오류 무시 블록), 재시도 초과/Retry=False면 Out_Dic_Error=Dic_Error→Final, 아니면 Init 재이동 / 'BRE'→Out_Dic_Error=Dic_Error→Final

### GetTransactionItem (58~83)
- 초기화(60~63): State='GetTransaction', Dic_Error={}
- 실행(64~69): 블록 오류 시 { [KSynapse] GetTransactionItem → .NET 스크립트 }
- 탈출(70~82): If (Dic_TransactionItem 비고 QI_TransactionItem 비면) →
  If Dbl_SuccessRate < Dbl_SuccessAssignmentRate → .NET 스크립트로 오류 발생(목표 성공률 미달) →
  Dic_Config['SuccessRate']=Dbl_SuccessRate, Out_Dic_Error=Dic_Error, Final로. Else → Process로

### Process (84~128)
- 초기화(86~89): State='Process', Dic_Error={}
- 실행(90~96): 블록 오류 시(RetryNumber_Process++, 블록 끝 이동) {
  [Business] Process → 마지막 오류 보기(오류 지움) } → [KSynapse] RecodeTransactionStatus (항상)
- 탈출(97~127): 블록 오류 시 { [Business] RecodeTransactionResult } →
  If Dic_Error 비면: [KSynapse] CollectError(성공 로그) → 번호++ → RetryNumber_Process=0 → GetTransactionItem로.
  Else Switch Status:
  'SE' → CloseApplications → If (RetryNumber_Process > MaxRetryNumber_Process Or NOT Retry) → 번호++, Retry=0 → **Init으로 이동**
  'BRE' → 번호++ → GetTransactionItem로

### Final (129~165)
- 초기화(131~134): State='Final', Dic_Error={}
- 실행(135~139): 블록 오류 시(RetryNumber_Finish++) { [Business] Step_Final }
- 탈출(140~164): 블록 오류 시 { CloseApplications } → If Dic_Error 비면 End로.
  Else 'SE': 재시도 초과/Retry=False → Out_Dic_Error=Dic_Error→End, 아니면 Final 재이동 / 'BRE': Out_Dic_Error=Dic_Error→End

### End (166~168)
레이블 End. 종료.

## [KSynapse] GetTransactionItem (16액션)

If Dic_Config['QueueID'] 비면(DT 모드):
- DT_TransactionResult 비면 Dic_TransactionItem={}
- Else if Int_TransactionNumber < RowsCount: 현재시각→행['StartTime'], Dic_TransactionItem=행['TransactionItem']
- Else Dic_TransactionItem={}
Else(큐 모드): "작업 큐 항목 처리" 루프 { 하위 흐름 종료 } — 1건 받으면 즉시 반환하는 트릭. 빈 큐면 QI_TransactionItem={}

## [KSynapse] CollectError (54액션)

1~3: 현재시각→Date_Exception, Dic_Error={}, 마지막 오류→Err_LastError(지움)
4~15: If ActionIndex<0(성공): Dic_Error에 Status='Success', State, TransactionNumber, TransactionTotal, TimeStamp → JSON 변환 → SystemMessage 전송 → Dic_Error={}
16~24: Else: 로그 → [KSynapse] TakeScreenshots →
  If 메시지가 '흐름을 실행하지 못함'으로 시작(데스크톱 흐름 오류): ErrorDetails에서 '오류 메시지:'~'추가 정보:' 파싱→Str_ErrMessage, Else Str_ErrMessage=Message
25~35: 접두사 분류 — '[KSynapse_BusinessRuleException]'→BRE/Retry=False, '[KSynapse_NoRetry]'→SE/Retry=False, 그 외→SE/Retry=True
36~39: 큐 모드+Process면 Retry=False, TransactionTotal=0
40~42: DT_TransactionData 있으면 TransactionTotal=RowsCount
43~52: State, TransactionNumber, Message, ActionIndex, ActionName, ErrorDetails, Location, SubflowName, TimeStamp 채움 → SystemMessage 전송

## [KSynapse] RecodeTransactionStatus (26액션)

큐 모드: Dic_Error 비면 큐 항목→처리됨. Else Status별: BRE→비즈니스 예외, SE→일반 예외 (메모=Dic_Error)
DT 모드: DT_TransactionData 컬럼 각각에 Dic_TransactionItem 값 역기록 →
DT_TransactionResult[n]['TransactionItem']=Dic_TransactionItem, ['EndTime']=현재시각, ['Result']='Success' 또는 Dic_Error['Status']

## [KSynapse] TakeScreenshots (3액션)

현재시각 → 'yyyyMMddHHmmssfff' 파일명 → 전체 화면 캡처를 Dic_Config['ScreenshotFolderPath']\{파일명}.png 저장

## 과제 커스터마이징 사례

- 해운A05: Process 상태가 [Business] Process 단일 호출 (표준형)
- 유통A10: 비즈니스 훅이 Step_A(Invoice 다운로드/업데이트), Step_B(PDF 변환+플래그 초기화), Step_C(플래그 기반 인보이스조회/엑셀/PDF 업로드, Skip 처리)로 분할됨.
  스텝별 결과는 DT_작업내역(10열), 트랜잭션 요약은 DT_트랜잭션(4열)으로 이원 관리.
  재수행 입력: In_Str_묶음처리/In_Str_순서/In_List_고객사번호. 시간대(11~15시) 분기로 정오/저녁 스케줄 구분.
