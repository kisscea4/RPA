---
name: "ksynapse-framework"
description: "사내 Power Automate Desktop(PAD) RPA 표준 프레임워크인 KSynapse Framework의 구조 지식과 과제 분석 절차. PAD 흐름을 분석·디버깅·리뷰·개발할 때, 특히 [KSynapse] 또는 [Business] 접두사 하위 흐름, Main/CallFramework, InitOnce/InitRetryable/SetTransactionData/Step_A~Step_Final, List_ProcessSettings 스텝 재개 커서, DT_TransactionData, DT_TransactionResult, Dic_Error, Dic_Config, BRE/SE 예외, MakeTransaction, RecodeTransactionStatus/Result, 작업 큐(Work Queue) 같은 요소가 보이거나 언급되면 반드시 이 스킬을 참조할 것. 유통A10, 해운A05처럼 [과제코드] 형식 이름의 사내 RPA 과제 흐름을 다룰 때, KSynapse 기반 신규 과제 개발·구조 설계·오류 처리 규약·재시도/재개 로직 질문, 어디까지가 표준 고정 영역이고 어디를 고쳐도 되는지 판단할 때도 사용."
---

# KSynapse Framework (PAD 트랜잭션 프레임워크)

사내 표준 RPA 프레임워크. UiPath REFramework와 동일한 사상의 **레이블+이동(goto) 기반 상태 머신**으로,
오류 분류·재시도·트랜잭션 기록·스크린샷·로그 전송을 프레임워크가 전담하고
비즈니스 로직은 `[Business]` 접두사 하위 흐름(훅)으로 위임한다. 기준 버전: **ver 1.0.2**.

이 문서는 구조와 계약(무엇을 지켜야 하는가)을 담는다.
행 번호 단위 액션 맵은 이 문서 맨 뒤 **부록**에 있다.

---

## 어디까지가 표준 고정 영역인가 (가장 먼저 볼 것)

과제 개발자가 **고쳐도 되는 곳은 정해져 있다.** 이걸 착각하면 표준 골격을 건드리는 잘못된 제안을 하게 된다.

| 영역 | 수정 가능 여부 |
|---|---|
| `Main`, `[KSynapse] *` 전부 | **고정.** 손대지 않는다 |
| `InitProcess` / `EndProcess` / `SystemMessage` / `MakeTransaction` / `DownloadBeforeTransaction` | **커스텀 액션.** 내부를 볼 수도 고칠 수도 없다 |
| `[Business] Process` | **고정 골격.** 개발자는 `List_ProcessSettings` 한 줄에 스텝 이름만 추가 |
| `[Business]` 나머지 훅 6개 | 과제가 자유롭게 구현 |
| `Step_A` / `Step_B` / … 및 업무 하위 흐름 | 과제가 자유롭게 구현 |

> **커스텀 액션은 블랙박스다.** 흐름 검색으로 어떤 변수·컬럼의 생성 지점이 안 잡힌다고 해서
> "그런 건 없다"고 단정하지 말 것. **표준 흐름이 그것을 참조하고 있다면 커스텀 액션이 제공하는 것이다.**
> 중단점을 걸고 실측해서 확인한 뒤에 말한다.

---

## 과제 분석 시작 절차

새 과제 흐름을 열었을 때 이 순서로 접근한다. **프레임워크 골격은 과제마다 동일하므로 다시 읽지 말 것** —
이 문서의 지식으로 대체하고, "과제별로 다른 것"만 화면에서 확인한다.

1. **제목줄·상태줄**: `[과제코드]흐름명`, 환경(RPA_DEV/PRD), `하위 흐름(N)`, 현재 탭 작업 수를 기록.
2. **하위 흐름 목록 전체**를 먼저 확보(드롭다운 스크롤). KSynapse 7개 + Business 7개 + Main을 뺀 나머지가 **그 과제의 실제 업무 흐름**이다. 이게 분석 대상.
3. **`[Business] Process` 2행 `List_ProcessSettings`** 를 본다. 이 과제가 트랜잭션 1건을 몇 개 스텝으로 쪼갰는지가 여기 다 나온다. 나머지 행은 표준이라 읽을 필요 없다.
4. **`[Business]` 훅을 순서대로** 읽는다: InitOnce → InitRetryable → SetTransactionData → RecodeTransactionResult → CloseApplications → Step_Final.
5. **스텝 하위 흐름(Step_A/B/C…)과 그것이 부르는 업무 흐름까지 내려간다.** 오케스트레이션만 보고 구현 품질을 평가하지 말 것.

전체 검색(`흐름 내부 검색`)이 가장 빠른 도구다. 변수명 하나로 정의처·사용처를 한 번에 잡을 수 있다.

리뷰 결론은 **"잘한 점 → 문제(심각도순) → 수정 우선순위"** 로 정리하고, 문제는 반드시 **흐름명 + 행 번호**로 지목한다.

> **개발 중인 과제 주의**: 스텁·테스트 흔적(빈 테이블 할당, 하드코딩된 값, 관계없는 하위 흐름 호출)을 결함으로 보고하지 말 것.
> 미완성인지 설계 결함인지 먼저 구분하고, 완성도와 무관하게 **지금 결정해야 하는 구조적 선택**만 짚는다.

---

## 실행 진입 구조

```
Main (주석 2개 + 호출 1개)
 └─ [KSynapse] CallFramework (5액션)
     └─ 오류 수집 블록 { InitProcess → [KSynapse] Framework → EndProcess }
```

- `Dic_Config`는 InitVariables가 읽기만 한다. 채우는 주체는 `InitProcess`(중앙 설정 로드)로 추정.
- Main의 두 번째 주석에 ProcessID·개발자·요약을 기재하는 것이 규약(공란인 과제가 많음).

---

## 상태 머신 ([KSynapse] Framework, 168액션)

4개 상태를 레이블과 `이동(Go to)`으로 순환한다. 각 상태는 동일 패턴:
**초기화**(`Str_CurrentState` 설정, `Dic_Error={}`) → **실행**(블록 오류 시 핸들러) → **탈출**(`Dic_Error` 검사 후 분기).

| 상태 | 구간 | 하는 일 | 성공 | SE | BRE |
|---|---|---|---|---|---|
| Init | 4~57 | InitOnce(최초 1회, `Bool_InitOnceEnd` 가드) → InitRetryable(재진입마다) → 대상 없으면 트랜잭션 생성 | 32행 → GetTransaction | CloseApplications 후 `MaxRetryNumber_Init`까지 Init 재시도(47행), 초과·Retry=False면 Out_Dic_Error→Final(44행) | 즉시 Final(53행) |
| GetTransaction | 58~83 | GetTransactionItem으로 다음 건 조회. 항목 없으면 성공률 검사 | 항목 있으면 Process(80행) / 없으면 Final(78행) | — | — |
| Process | 84~128 | [Business] Process → 오류 지움 → **RecodeTransactionStatus 항상** → RecodeTransactionResult | CollectError(성공 로그)→번호++→GetTransaction(104~106행) | CloseApplications. 재시도 초과·Retry=False면 번호++(114~117행). **항상 Init으로 이동**(119행) | 번호++→GetTransaction(122~124행) |
| Final | 129~165 | [Business] Step_Final | End(146행) | `MaxRetryNumber_Finish`까지 Final 재시도(156행), 초과 시 Out_Dic_Error→End | Out_Dic_Error→End(158~161행) |

핵심 포인트:

- **Process의 SE는 다음 건이 아니라 Init으로 돌아간다**(119행). 앱 상태가 깨졌다고 보고 재초기화 후 이어서 처리.
  재시도 한도 내면 `Int_TransactionNumber`가 올라가지 않으므로 **같은 건을 다시 잡는다.**
- `CloseApplications`는 **SE 경로 3곳(38·112·142행)에서만** 호출된다. 즉 SE 복귀 시 브라우저·Excel 핸들은 사라진다.
- `Out_Dic_Error`가 비어 있지 않으면 Step_Final은 실패 경로(실패 메일 등)로 분기하는 것이 관례.
- 트랜잭션 기록은 2층 보장: `[KSynapse] RecodeTransactionStatus`(건 상태) + `[Business] RecodeTransactionResult`(과제별 훅).
  후자는 **성공·SE·BRE 무관하게 Process 탈출 시 항상 호출**된다(98~99행) — 부분 성공 보존의 핵심 지점.

---

## 스텝 재개 커서 — [Business] Process 표준 골격

`[Business] Process`는 과제마다 새로 짜는 훅이 **아니다.** 아래가 전부이며 고정이다.

```
1 지역 프로세스 세팅
2   List_ProcessSettings = ['Step_A', 'Step_B']       ← 개발자가 편집하는 유일한 줄
3 종료 지역
4 지역 프로세스 실행
5   반복: DT_TransactionResult[Int_TransactionNumber]['Step'] 에서
         List_ProcessSettings.Count - 1 까지 1단계 → Int_Step
6     하위 흐름 실행 %List_ProcessSettings[Int_Step]%
7     DT_TransactionResult[Int_TransactionNumber]['Step'] = Int_Step + 1
8   End
9 종료 지역
```

- 개발자는 스텝 하위 흐름(`Step_A`, `Step_B`…)을 만들고 **2행 목록에 이름만 추가**한다. 5~7행은 손대지 않는다.
- `'Step'` 컬럼은 트랜잭션 행의 **표준 컬럼**이며 `MakeTransaction`이 생성한다.
  과제 흐름 어디에도 초기화 코드가 없는 것이 정상이다.
- SE로 Init 복귀 후 같은 건을 다시 잡아도 **실패한 스텝부터 재개**된다. 앞 스텝은 다시 돌지 않는다.

여기서 따라오는 설계 규칙:

1. **각 스텝은 self-contained 여야 한다.** 중간 스텝부터 재개될 수 있는데, SE 경로에서 `CloseApplications`가 돌아
   앞 스텝이 열어둔 브라우저·Excel 핸들은 이미 없다. 스텝 진입부에서 필요한 앱을 스스로 확보할 것.
2. **스텝 내부에서 예외를 삼키지 말 것.** 오류를 자체 블록으로 처리하고 정상 반환하면
   미완료 상태로 커서가 다음 스텝으로 넘어간다. 기록만 하고 반드시 재발생시킨다.
3. **스텝 단위 재개는 스텝 내부 재작업을 막아주지 않는다.** 스텝 안에서 100건 중 90건 처리 후 실패하면
   커서는 그대로라 전량 재작업이다. 하위 항목 단위 Skip 로직은 별도로 필요하다.
4. 스텝 이름이 동적 호출(`%List_ProcessSettings[Int_Step]%`)이라 **오타는 런타임 오류**이고 호출처 정적 추적도 끊긴다.

---

## 예외 규약 (가장 중요)

비즈니스 흐름은 **오류 메시지 접두사**로 예외 유형을 프레임워크에 전달한다 (CollectError 26~34행):

| 접두사 | 분류 | Retry | 의미 |
|---|---|---|---|
| `[KSynapse_BusinessRuleException]` | BRE | False | 업무 규칙 위반. 해당 건 건너뛰고 다음 건 |
| `[KSynapse_NoRetry]` | SE | False | 재시도 무의미한 시스템 오류 |
| (그 외 모든 오류) | SE | True | 재시도 대상 시스템 오류 |

- **대/소문자를 구분해 비교한다.** 접두사에 오타가 나면 조용히 일반 SE로 떨어져 무의미한 재시도를 반복한다.
  분류가 이상하면 제일 먼저 접두사 철자를 의심할 것.
- **오류를 던지는 house 패턴은 `.NET 스크립트 실행`이다.** 네이티브 throw 액션을 쓰지 않는다.
  Framework 74행(목표 성공률 미달)이 그 예이므로, 그 액션을 복사해 메시지만 바꾸는 것이 가장 안전하다.
- 하위 흐름 호출 중 발생한 오류는 메시지가 `흐름을 실행하지 못함`으로 시작한다. 이때 CollectError 20~21행이
  `ErrorDetails`에서 `오류 메시지:` ~ `추가 정보:` 사이만 잘라 `Str_ErrMessage`로 쓴다(1.0.2 추가분).
  **스텝 하위 흐름 안에서 오류를 발생시키는 구조라면 이 파싱 후에도 접두사가 맨 앞에 오는지 실측 확인이 필요하다.**
- 작업 큐 모드 + Process 상태면 Retry=False로 강제(36~38행). 재시도는 큐가 담당하기 때문.

---

## 트랜잭션 소스 이중 모드

`Dic_Config['QueueID']` 유무로 결정된다:

- **비어 있음(DT 모드)**: `DT_TransactionResult[n]['TransactionItem']` 사전을 사용.
  StartTime/EndTime/Result('Success'|'BRE'|'SE')/Step을 행에 기록.
- **있음(큐 모드)**: Power Automate 작업 큐에서 1건씩 처리
  ("작업 큐 항목 처리" 루프에서 항목 받고 즉시 `하위 흐름 종료`하는 트릭).
  결과는 큐 항목 상태(처리됨/비즈니스 예외/일반 예외 + Dic_Error 메모)로 기록.

**큐 모드에서는 `DT_TransactionResult`를 쓰지 않으므로 스텝 재개 커서도 함께 무력화된다.**
큐 전환 계획이 있으면 이 점을 먼저 검토할 것.

---

## 트랜잭션 행 생성 경로

Framework 17~25행.

```
17 If DT_TransactionData 비어 있음
18   DownloadBeforeTransaction              ← 커스텀 액션
19   If Str_TransactionFilePath 비어있지 않음
20     CSV 파일에서 읽기 → DT_TransactionResult   ← 재개 모드
21   Else
22     [Business] SetTransactionData          ← 과제가 DT_TransactionData(처리 대상 목록) 생성
23     MakeTransaction                        ← 커스텀 액션: DT_TransactionResult 행 생성
24   End
25 End
```

- `[Business] SetTransactionData`의 책임은 **처리 대상 목록(`DT_TransactionData`)까지**다.
  `TransactionItem`/`StartTime`/`EndTime`/`Result`/`Step` 같은 트랜잭션 행 컬럼은 `MakeTransaction`이 붙인다.
  과제가 직접 만들 필요도, 만들어서도 안 된다.
- **재개 모드(20행)는 SetTransactionData와 MakeTransaction을 둘 다 건너뛴다.**
  두 곳에 의존하는 초기화는 재개 실행에서 실행되지 않는다.
- CSV 복원 값은 문자열이므로, 숫자로 쓰는 컬럼은 형변환 이슈를 확인할 것.

---

## 비즈니스 훅 계약 — 과제가 구현하는 것

| 하위 흐름 | 호출 시점 | 책임 |
|---|---|---|
| [Business] InitOnce | 최초 Init 1회 | 설정/날짜/경로/계정/메일 변수, 작업대상 파일 준비 |
| [Business] InitRetryable | **Init 재진입마다** | 앱 실행·로그인 등 재시도 가능한 초기화 |
| [Business] SetTransactionData | Init에서 대상 없을 때 | `DT_TransactionData`(처리 대상 목록) 생성 + 과제별 누적 변수 초기화 |
| [Business] Process | 트랜잭션 1건마다 | **표준 고정.** `List_ProcessSettings`에 스텝 이름만 추가 |
| [Business] RecodeTransactionResult | **Process 탈출 시 매건(결과 무관)** | 과제별 결과 기록(결과 Excel 등) |
| [Business] CloseApplications | SE 발생 시 | 앱 정리(브라우저/Excel 닫기) |
| [Business] Step_Final | Final 상태 | 결과파일 작성·업로드·메일 발송. `Out_Dic_Error` 유무로 성공/실패 분기 |

### 훅 배치 판단 기준

- **전 트랜잭션 공통 앱/세션** → `InitRetryable`. 재진입마다 실행되므로 SE 복귀 후 자동 복구된다.
  단 **중복 실행 가드**(이미 열려 있으면 스킵)를 반드시 넣을 것.
  유휴 타임아웃이 있는 사내 시스템이면 로그인은 InitRetryable, **세션 유효성 확인은 실제 사용 스텝 진입부**에 둔다.
- **트랜잭션별로 달라지는 로그인**(건마다 계정이 다름) → 스텝 머리.
  `InitRetryable`에 두면 **최초 Init 시점엔 `Dic_TransactionItem`이 비어 있어** 첫 건에서 값을 못 읽는다.
  꼭 InitRetryable에서 처리해야 하면 `DT_TransactionData[Int_TransactionNumber]`를 직접 읽고 인덱스 초과를 가드할 것.
- **Step_Final을 무겁게 만들지 말 것**(운영 선호). Final 실패는 전체 산출물 손실 + `MaxRetryNumber_Finish` 제한으로 이어진다.
  트랜잭션별로 쪼갤 수 있는 후처리는 스텝으로 내리는 편이 실패 반경이 작다.

---

## 주요 변수·Config 키

- **프레임워크 변수**: `Str_CurrentState`, `Dic_Error`, `Out_Dic_Error`, `Dic_TransactionItem`/`QI_TransactionItem`,
  `DT_TransactionData`, `DT_TransactionResult`, `Int_TransactionNumber`(0-based), `Int_RetryNumber_Init/Process/Finish`,
  `Bool_InitOnceEnd`, `Bool_IsPRD`, `Dbl_SuccessRate`, `Dbl_SuccessAssignmentRate`, `Str_TransactionFilePath`,
  `Str_InputFolderPath`/`Str_OutputFolderPath`/`Str_DataFolderPath`, `List_ProcessSettings`, `Int_Step`
- **Dic_Config 키**: `QueueID`, `SuccessRate`, `SuccessAssignmentRate`, `IsPRD`, `InputFolderPath`, `OutputFolderPath`,
  `DataFolderPath`, `ScreenshotFolderPath`, `MaxRetryNumber_Init/Process/Finish` (+과제별 키)
- **Dic_Error 스키마**: Status('Success'|'BRE'|'SE'), Retry, State, TransactionNumber, TransactionTotal,
  Message, ActionIndex, ActionName, ErrorDetails, Location, SubflowName, TimeStamp

### PAD 리터럴 표기 (자주 틀리는 것)

| 형식 | 표기 | 비고 |
|---|---|---|
| 목록 | `%[ 'a', 'b' ]%` | |
| 데이터 테이블 | `%{ ^['h1','h2'], ['a','b'] }%` | `^`가 헤더 행 |
| 빈 데이터 테이블(헤더만) | `%{ ^['h1','h2'], }%` | **끝의 쉼표 필요** |
| 사용자 지정 개체 | `%{{ 'k': 'v' }}%` | **중괄호 두 겹.** 한 겹이면 데이터 테이블로 해석돼 "사용자 지정 개체가 아닙니다" 오류 |
| 빈 사용자 지정 개체 | `%{{ }}%` | 안 되면 `JSON을 사용자 지정 개체로 변환` 액션에 `{}` |

**데이터 테이블은 참조형이다.** 빈 테이블을 반복문 밖에서 한 번 만들어 여러 키에 넣으면
전부 같은 객체를 가리켜 데이터가 섞인다. 반복문 **안에서 매번 새로** 만들 것.

---

## 과제 분석·리뷰 체크포인트

실제 과제에서 반복 발견된 리스크 패턴.

1. **0건 위장 성공**: SetTransactionData가 빈 결과를 빈 테이블로 대체해 정상 진행하면 업스트림 실패가 "0건 성공"으로 위장된다.
   대상 0건이면 BRE로 알릴 것.
2. **부분 성공 기록 유실**: 결과 누적 갱신이 `RecodeTransactionResult` 밖(예: Process 성공 경로 안)에만 있으면,
   SE로 끝난 건의 앞선 성공분이 통째로 날아간다. **갱신 경로는 이 훅 하나로 고정.**
3. **스텝별 기록 이원화**: 스텝별 결과 테이블(예: DT_작업내역)을 따로 두는 것은 정상 패턴이나,
   갱신 경로를 한 곳으로 모으고 트랜잭션 Result는 스텝 결과에서 파생시킬 것.
4. **필터 매칭 실패 시 이전 반복 데이터 재사용**: For each 안 Else 분기가 주석만 있고 필터 테이블을 초기화하지 않으면
   직전 반복 결과가 재사용돼 중복 처리된다.
5. **고정 대기 + 파일 검증 부재**: 다운로드 후 고정 N초 대기만 있으면 지연 시 미완성 파일로 진행한다.
   파일 존재·크기 안정화·잠금 해제를 확인할 것.
6. **하드코딩**: 계정 ID, 고객사 코드, 로컬 절대경로(`C:\Users\...\Desktop\...`),
   시간대 분기(`'11'<HH<'15'` 같은 문자열 비교)는 전부 제거 대상. 무인 머신에서 안 돈다.
7. **스텝 재진입 시 앱 전제 / 예외 삼킴 / 스텝 내부 재작업** — 위 "스텝 재개 커서" 규칙 1~3 참조.

---

## 알아두면 쓰는 동작

- **`Dic_TransactionItem` 역기록**: RecodeTransactionStatus 14~15행이 DT_TransactionData의 각 컬럼에
  `Dic_TransactionItem` 값을 되써 넣는다. 즉 **Process 중 `Dic_TransactionItem`을 수정하면 원본 DT에 자동 반영**된다.
  건별 진행 상태를 별도 저장 없이 보존할 때 쓸 수 있다.
- **성공률 게이트**: 트랜잭션 소진 시 `Dbl_SuccessRate < Dbl_SuccessAssignmentRate`면 오류를 발생시킨다(72~74행).
  목표 성공률 미달이 Final 실패로 이어지므로 `SuccessAssignmentRate` 값 설정에 주의.

---

## 진단 팁

- **오류 지점 추적**: SystemMessage로 전송된 JSON(`Dic_Error`)의 State·SubflowName·ActionName·Location 확인 →
  `Dic_Config['ScreenshotFolderPath']`의 타임스탬프 png(`yyyyMMddHHmmssfff.png`)와 대조.
- **재수행**: `In_Str_묶음처리` 같은 입력 변수로 특정 묶음/상태만 재처리하는 패턴이 과제별로 존재.
  InitOnce와 다운로드 흐름의 If 분기를 확인할 것.
- **커스텀 액션 산출물 확인**: `MakeTransaction` 등이 무엇을 만드는지는 중단점(23행 직후)을 걸고
  `DT_TransactionResult`의 열을 직접 보는 것이 유일한 방법이다.

---

# 부록 — 하위 흐름 상세 액션 맵

화면 실측 구조(ver 1.0.2, 전 구간 확인). 행 번호는 실측값이며 과제 간 동일하다.

## 표준 하위 흐름 구성

KSynapse 7개 + Business 훅 7개 + Main = 15개가 골격. 그 외는 과제 고유 업무 흐름이다.

```
Main
[KSynapse] CallFramework / Framework / InitVariables / GetTransactionItem
           RecodeTransactionStatus / CollectError / TakeScreenshots
[Business] InitOnce / InitRetryable / SetTransactionData / Process
           RecodeTransactionResult / CloseApplications / Step_Final
```

커스텀 모듈 액션(자산 라이브러리, 하위 흐름 아님 · 내부 확인/수정 불가):
`InitProcess`, `EndProcess`, `SystemMessage`, `MakeTransaction`, `DownloadBeforeTransaction`

---

## Main (3액션)

1. 설명: `[KSynapse] Framework ver 1.0.2` / CollectError에 데스크톱 흐름 실행 오류 메시지 parsing 추가
2. 설명: ProcessID - ProcessName / 프로세스 개발자 성명 / 요약 설명 (기재 규약)
3. 하위 흐름 실행: `[KSynapse] CallFramework`

## [KSynapse] CallFramework (5액션)

```
1 블록 오류 시 "Main: 오류 정보 수집"
2   InitProcess          (커스텀 — Dic_Config 로드 추정)
3   하위 흐름 실행: [KSynapse] Framework
4   EndProcess           (커스텀)
5 End
```

## [KSynapse] InitVariables (14액션)

```
1  지역 InitVariable
2  Out_Dic_Error = {}
3  Bool_InitOnceEnd = False
4  Int_RetryNumber_Init = 0
5  Int_RetryNumber_Process = 0
6  Int_RetryNumber_Finish = 0
7  Int_TransactionNumber = 0                       ← 0-based
8  Dbl_SuccessRate = Dic_Config['SuccessRate']
9  Dbl_SuccessAssignmentRate = Dic_Config['SuccessAssignmentRate']
10 Bool_IsPRD = Dic_Config['IsPRD']
11 Str_InputFolderPath = Dic_Config['InputFolderPath']
12 Str_OutputFolderPath = Dic_Config['OutputFolderPath']
13 Str_DataFolderPath = Dic_Config['DataFolderPath']
14 종료 지역
```

`DT_TransactionData` / `DT_TransactionResult`는 여기서 초기화하지 않는다.

---

## [KSynapse] Framework (168액션) — 상태 머신 본체

### Start (1~3)
`[KSynapse] InitVariables` 실행.

### Init (4~57)

초기화(6~9): `Str_CurrentState='Init'`, `Dic_Error={}`

실행(10~27) — 블록 오류 시(`Int_RetryNumber_Init` 1 증가, 블록 끝으로 이동):

```
12 If Bool_InitOnceEnd <> True
13   [Business] InitOnce
14   Bool_InitOnceEnd = True
16 [Business] InitRetryable
17 If DT_TransactionData 비어 있음
18   DownloadBeforeTransaction              (커스텀)
19   If Str_TransactionFilePath 비어있지 않음
20     CSV 파일에서 읽기 → DT_TransactionResult    ← 재개 모드
21   Else
22     [Business] SetTransactionData
23     MakeTransaction                      (커스텀 — DT_TransactionResult 행 생성)
```

탈출(28~56):

```
29 If Dic_Error 비어 있음
31   Int_RetryNumber_Init = 0
32   이동 GetTransactionItem
33 Else
34   Switch Dic_Error['Status']
35   Case 'SE'
37     블록 오류 시(계속 진행) { 38 [Business] CloseApplications }
40     If Int_RetryNumber_Init > Dic_Config['MaxRetryNumber_Init'] Or NOT(Dic_Error['Retry'])
42       Int_RetryNumber_Init = 0
43       Out_Dic_Error = Dic_Error
44       이동 Final
45     Else
47       이동 Init                          ← 재시도
49   Case 'BRE'
51     Int_RetryNumber_Init = 0
52     Out_Dic_Error = Dic_Error
53     이동 Final
```

### GetTransactionItem (58~83)

초기화(60~63): `Str_CurrentState='GetTransaction'`, `Dic_Error={}`

실행(64~69): 블록 오류 시 { `[KSynapse] GetTransactionItem` → .NET 스크립트 }

탈출(70~82):

```
71 If (Dic_TransactionItem 비어있음 And QI_TransactionItem 비어있음) = True
72   If Dbl_SuccessRate < Dbl_SuccessAssignmentRate
74     .NET 스크립트 실행 → 오류 발생(목표 성공률 미달)   ← throw house 패턴
76   Dic_Config['SuccessRate'] = Dbl_SuccessRate
77   Out_Dic_Error = Dic_Error
78   이동 Final
79 Else
80   이동 Process
```

### Process (84~128)

초기화(86~89): `Str_CurrentState='Process'`, `Dic_Error={}`

실행(90~96):

```
91 블록 오류 시(Int_RetryNumber_Process 1 증가, 블록 끝으로 이동)
92   [Business] Process
93   마지막 오류 보기 → Err_오류지우기 (오류 값 지움)
95 [KSynapse] RecodeTransactionStatus        ← 오류 여부 무관 항상 실행
```

탈출(97~127):

```
98  블록 오류 시 { 99 [Business] RecodeTransactionResult }     ← 결과 무관 항상 실행
101 If Dic_Error 비어 있음
103   [KSynapse] CollectError                (성공 로그)
104   Int_TransactionNumber 1 증가
105   Int_RetryNumber_Process = 0
106   이동 GetTransactionItem
107 Else
109   Switch Dic_Error['Status']
110   Case 'SE'
111     블록 오류 시(계속 진행) { 112 [Business] CloseApplications }
114     If Int_RetryNumber_Process > Dic_Config['MaxRetryNumber_Process'] Or NOT(Dic_Error['Retry'])
116       Int_TransactionNumber 1 증가       ← 이 건 포기
117       Int_RetryNumber_Process = 0
119     이동 Init                            ← 조건 무관, 항상 Init
120   Case 'BRE'
122     Int_TransactionNumber 1 증가
123     Int_RetryNumber_Process = 0
124     이동 GetTransactionItem
```

> 114행 조건이 거짓이면 번호가 유지된 채 Init → GetTransaction → **같은 건 재수행**.
> 이때 `'Step'` 커서가 살아 있어 실패한 스텝부터 재개된다.

### Final (129~165)

초기화(131~134): `Str_CurrentState='Final'`, `Dic_Error={}`

실행(135~139): 블록 오류 시(`Int_RetryNumber_Finish` 1 증가) { 137 `[Business] Step_Final` }

탈출(140~164):

```
141 블록 오류 시(계속 진행) { 142 [Business] CloseApplications }
144 If Dic_Error 비어 있음 → 146 이동 End
147 Else
148   Switch Dic_Error['Status']
149   Case 'SE'
150     If Int_RetryNumber_Finish > Dic_Config['MaxRetryNumber_Finish'] Or NOT(Dic_Error['Retry'])
152       Out_Dic_Error = Dic_Error
153       이동 End
154     Else
156       이동 Final                         ← 재시도
158   Case 'BRE'
160     Out_Dic_Error = Dic_Error
161     이동 End
```

### End (166~168)
레이블 End. 종료 지역.

---

## [Business] Process (9액션) — 표준 고정

```
1 지역 프로세스 세팅
2   List_ProcessSettings = ['Step_A', 'Step_B']       ← 개발자 편집 지점
3 종료 지역
4 지역 프로세스 실행
5   반복: DT_TransactionResult[Int_TransactionNumber]['Step'] 에서
         List_ProcessSettings.Count - 1 까지 1단계 → Int_Step
6     하위 흐름 실행 %List_ProcessSettings[Int_Step]%
7     DT_TransactionResult[Int_TransactionNumber]['Step'] = Int_Step + 1
8   End
9 종료 지역
```

## [KSynapse] GetTransactionItem (16액션)

```
1  If Dic_Config['QueueID'] 비어 있음               ← DT 모드
2    If DT_TransactionResult 비어 있음
3      Dic_TransactionItem = {}
4    Else if Int_TransactionNumber < DT_TransactionResult.RowsCount
5      현재 날짜/시간 → Date_TransactionTimeStamp
6      DT_TransactionResult[Int_TransactionNumber]['StartTime'] = Date_TransactionTimeStamp
7      Dic_TransactionItem = DT_TransactionResult[Int_TransactionNumber]['TransactionItem']
8    Else
9      Dic_TransactionItem = {}
11 Else                                            ← 큐 모드
12   작업 큐 항목 처리 (%Dic_Config['QueueID']% → QI_TransactionItem)
13     하위 흐름 종료                                ← 1건 받고 즉시 반환하는 트릭
15   QI_TransactionItem = []                        (빈 큐)
```

## [KSynapse] RecodeTransactionStatus (26액션)

```
1  지역 트랜잭션 기록
2  If Dic_Config['QueueID'] 비어있지 않음            ← 큐 모드
3    If Dic_Error 비어 있음 → 4 큐 항목을 '처리됨'으로 업데이트
5    Else Switch Dic_Error['Status']
7      Case 'BRE' → 8  '비즈니스 예외' + Dic_Error 메모
9      Case 'SE'  → 10 '일반 예외' + Dic_Error 메모
13 Else                                            ← DT 모드
14   각각의 경우 DT_TransactionData.Columns 내 각 Str_TransactionColumnName
15     DT_TransactionData[Int_TransactionNumber][컬럼] = Dic_TransactionItem[컬럼]   ← 역기록
17   현재 날짜/시간 → Date_TransactionTimeStamp
18   DT_TransactionResult[n]['TransactionItem'] = Dic_TransactionItem
19   DT_TransactionResult[n]['EndTime'] = Date_TransactionTimeStamp
20   If Dic_Error 비어 있음 → 21 ['Result'] = 'Success'
22   Else                  → 23 ['Result'] = Dic_Error['Status']
```

## [KSynapse] CollectError (54액션)

```
1~3   현재시각→Date_Exception, Dic_Error={}, 마지막 오류→Err_LastError(지움)
4     If Err_LastError.ActionIndex < 0                    ← 성공 경로
6~14    Status='Success', State, TransactionNumber,
        TransactionTotal=DT_TransactionData.RowsCount, TimeStamp
        → JSON 변환 → SystemMessage 전송 → Dic_Error={}
16    Else                                                ← 예외 경로
18      로그 메시지: Err_LastError.Message
19      [KSynapse] TakeScreenshots
20      If Err_LastError.Message 시작 문자 '흐름을 실행하지 못함' (대/소문자 구분)
21        텍스트 자르기: ErrorDetails의 '오류 메시지:' ~ '추가 정보:' → Str_ErrMessage
22      Else
23        Str_ErrMessage = Err_LastError.Message
25    지역 Queue에 예외 로그 정보 입력
26      If Str_ErrMessage 시작 '[KSynapse_BusinessRuleException]' (대/소문자 구분)
27        Status='BRE'  28 Retry=False
29      Else if 시작 '[KSynapse_NoRetry]' (대/소문자 구분)
30        Status='SE'   31 Retry=False
32      Else
33        Status='SE'   34 Retry=True
36    If Dic_Config['QueueID'] 비어있지 않음 And Str_CurrentState='Process'
37      Retry=False   38 TransactionTotal=0
40    If DT_TransactionData 비어있지 않음 → 41 TransactionTotal=RowsCount
43~51 State, TransactionNumber, Message, ActionIndex, ActionName,
      ErrorDetails, Location, SubflowName, TimeStamp
52    SystemMessage 전송
```

## [KSynapse] TakeScreenshots (3액션)

현재시각 → `yyyyMMddHHmmssfff` 파일명 → 전체 화면 캡처를
`Dic_Config['ScreenshotFolderPath']\{파일명}.png` 로 저장.

---

## 과제 사례

### 해운A05 (화주사시스템클레임조회)

- 트랜잭션 단위 = 화주사 1건(VASCOR 3사 / VTC 4사). 대상 목록은 Input 엑셀에서 읽어 `DT_TransactionData` 구성.
- `List_ProcessSettings = ['Step_A', 'Step_B']` — Step_A는 화주사 시스템 클레임 추출, Step_B는 ESPA 선적정보 매칭.
  전 화주사 공통인 ESPA 조회를 Step_Final이 아닌 스텝으로 내려 실패 반경을 화주사 1건으로 좁힌 구성.
- `SetTransactionData`가 `Dic_화주사별DT`(Key=Corp, Value=빈 결과 테이블)와 `Dic_VTC`를 함께 초기화.
  결과 엑셀 시트가 화주사별 고정이라 실패·0건 화주사도 키가 있어야 하기 때문.
- `InitRetryable`에서 `%변수%_로그인` 형태로 사이트별 로그인 흐름을 동적 호출.
  로그인 흐름은 사이트 단위(`VASCOR_로그인`, `VTC_로그인`)로 두고 계정은 파라미터로 전달.

### 유통A10

- `List_ProcessSettings`에 Step_A(Invoice 다운로드/업데이트), Step_B(PDF 변환+플래그 초기화),
  Step_C(플래그 기반 인보이스조회/엑셀/PDF 업로드, Skip 처리) 3개.
- 스텝별 결과는 `DT_작업내역`(10열), 트랜잭션 요약은 `DT_트랜잭션`(4열)으로 이원 관리.
- 재수행 입력: `In_Str_묶음처리` / `In_Str_순서` / `In_List_고객사번호`.
  시간대(11~15시) 분기로 정오/저녁 스케줄 구분.
